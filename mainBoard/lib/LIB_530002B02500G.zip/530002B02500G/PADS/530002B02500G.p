*PADS-LIBRARY-PART-TYPES-V9*

530002B02500G 529802B02500G I ANA 6 1 0 0 0
TIMESTAMP 2026.06.18.02.29.13
"Mouser Part Number" 532-530002B02500G
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Aavid/530002B02500G?qs=U7T%2FEnMyvTvnsUSILY5qjg%3D%3D
"Manufacturer_Name" Aavid Thermalloy
"Manufacturer_Part_Number" 530002B02500G
"Description" AAVID THERMALLOY - 530002B02500G - HEAT SINK, 2.6K/W, TO-220
"Datasheet Link" https://datasheet.datasheetarchive.com/originals/distributors/Datasheets-DGA11/2294712.pdf
GATE 1 2 0
530002B02500G
1 0 U 1
2 0 U 2

*END*
*REMARK* SamacSys ECAD Model
702916/1007095/2.50/2/4/Undefined or Miscellaneous
